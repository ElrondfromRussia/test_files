import requests


class Protocol:
    def __init__(self):
        self.vers = ""

    def connect(self):
        print("connection")

    def send(self, url):
        print("sending")

    def get(self, url, path_for_save):
        print("getting")
        try:
            ufr = requests.get(url)
            f = open(path_for_save, "wb+")
            f.write(ufr.content)
            f.close()
            return 0
        except BaseException as ex:
            print(ex)
            return 1

    def get_proxy(self, url, path_for_save):
        proxy = 'alogin:parol@10.1.1.1:3128'
        proxy = {'http': 'http://' + proxy, 'https': 'https://' + proxy}
        bb3 = requests.get(url, proxies=proxy)
        f = open(path_for_save, "wb")
        f.write(bb3.content)
        f.close()

