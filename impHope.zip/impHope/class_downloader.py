from os_platf_utils import get_binaries_dir_path
from class_protocol import Protocol


class Downloader:
    def __init__(self):
        self.filters = []
        self.Protoc = Protocol()

    def dowmload_file(self, filepath, filename):
        try:
            print(get_binaries_dir_path() + "/" + filename, " ",  filepath)
            res = self.Protoc.get(filepath, get_binaries_dir_path() + "/" + filename)
            if res:
                return 1
            return 0
        except BaseException as ex:
            print(ex)
            return 1


