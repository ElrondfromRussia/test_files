

class Downloader:
    def __init__(self):
        self.filters = []

    def dowmload_file(self, filename, filepath):
        print(filename, " ", filepath)
