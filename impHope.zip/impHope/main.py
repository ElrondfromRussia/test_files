import basilisk
from os_platf_utils import clear_folder, get_temp_dir


def main():
    print("start")
    basil = basilisk.Basilisk()
    try:
        basil.start()
    except:
        print("bad start")


def clean_all():
    print("cleaning")
    try:
        print("deleting")
        clear_folder(get_temp_dir())
    except:
        print("BAD DELETE")



########################################
if __name__ == '__main__':
    main()
    clean_all()
    im = input("Press")