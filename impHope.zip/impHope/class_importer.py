import ctypes as ct
from os_platf_utils import get_binary_file_path, is_windows


class Importer:
    def __init__(self):
        print("I am importer")
        self.libs = []

    def import_lib(self, libname, libpath):
        newLib = None
        if libpath == '':
            abs_name = get_binary_file_path(libname)
        else:
            abs_name = libpath + '/' + libname

        print(abs_name)
        try:
            if is_windows():
                newLib = ct.CDLL(abs_name)
            else:
                newLib = ct.cdll.LoadLibrary(abs_name)
        except:
            print("BAD IMPORT")
        else:
            print("adding lib")
            if newLib not in self.libs:
                self.libs.append(newLib)
        return newLib

    def free_lib(self, lib_descr):
        print("freeing")
        try:
            if is_windows():
                ct.windll.kernel32.FreeLibrary(lib_descr._handle)
        except BaseException as ex:
            print("Bad freeing: ", ex)

    def free_all_libs(self):
        try:
            for lib in self.libs:
                self.free_lib(lib)
        except BaseException as ex:
            print("Bad ALL freeing: ", ex)
