import ctypes as ct
from os_platf_utils import get_binary_file_path


class Importer:
    def __init__(self):
        print("I am importer")
        self.libs = []

    def import_lib(self, libname, libpath):
        newLib = None
        if libpath == '':
            abs_name = get_binary_file_path(libname)
        else:
            abs_name = libpath + '/' + libname

        print(abs_name)
        try:
            newLib = ct.CDLL(abs_name)
        except:
            print("BAD IMPORT")
        else:
            if newLib not in self.libs:
                self.libs.append(newLib)
        return newLib
