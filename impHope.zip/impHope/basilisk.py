import ctypes

from os_platf_utils import get_bin_folder, is_windows, \
    get_libs, get_temp_dir

import class_importer as imp
import class_downloader as dwn


LIB1_32_PATHl = "lib1_32_l.so"
LIB1_64_PATHl = "lib1_64_l.so"
LIB2_32_PATHl = "lib2_32_l.so"
LIB2_64_PATHl = "lib2_64_l.so"
LIB1_32s_PATHl = "lib1_32s_l.so"
LIB1_64s_PATHl = "lib1_64s_l.so"

LIB1_32_PATHw = "lib1_32_w_st.so"
LIB1_32_PATHws = "lib1_32_wpss.so"
LIB2_32_PATHws = "lib2_32_wss.so"
LIB1_64_PATHw = "lib1_64_w_st.so"
LIB1_64_PATHws = "lib1_64_wpss.so"
LIB2_64_PATHws = "lib2_64_wpss.so"


class Basilisk:
    def __init__(self):
        self.LIBS = get_libs()
        self.LIB_PATH = get_bin_folder()

    def print_libs(self):
        for l in self.LIBS:
            print(l)

    def start(self):
        print("curr temp dir: ", get_temp_dir())
        mImp = imp.Importer()
        try:
            if is_windows():
                print("windows")
                lib1 = mImp.import_lib(LIB1_32_PATHws, '')
                lib1.ClibToPy_new.restype = ctypes.c_void_p
                lib1.ClibToPy_print.restype = ctypes.c_int
                exemp1 = lib1.ClibToPy_new()
                print(lib1.ClibToPy_print(exemp1))

                lib2 = mImp.import_lib(LIB2_64_PATHws, '')
                lib2.ClibToPy2_new.restype = ctypes.c_void_p
                lib2.ClibToPy2_print.restype = ctypes.c_int
                exemp2 = lib2.ClibToPy2_new()
                print(lib2.ClibToPy2_print(exemp2))
            else:
                print("linux")
                lib1 = mImp.import_lib(LIB1_64_PATHl, '')
                lib1.ClibToPy_new.restype = ctypes.c_void_p
                lib1.ClibToPy_print.restype = ctypes.c_int
                exemp1 = lib1.ClibToPy_new()
                print(lib1.ClibToPy_print(exemp1))

                lib2 = mImp.import_lib(LIB2_64_PATHl, '')
                lib2.ClibToPy2_new.restype = ctypes.c_void_p
                lib2.ClibToPy2_print.restype = ctypes.c_int
                exemp2 = lib2.ClibToPy2_new()
                print(lib2.ClibToPy2_print(exemp2))
        except:
            print("BAD STATIC LINKING")

        print("-----------------------------")
        self.print_libs()
        print("-----------------------------")
        ans = input("Type lib num: ")
        try:
            while not ans == 'q':
                num = 0
                try:
                    num = int(ans)
                except:
                    print("Type number")
                    continue
                else:
                    if num < len(self.LIBS):
                        mImp.import_lib(self.LIBS[num], self.LIB_PATH)
                    else:
                        print("No such lib")
                finally:
                    ans = input("Type lib num: ")
        except:
            print("Wrong input or wrong operation")
