import os
import sys
import platform
import shutil
import tempfile
import stat
import subprocess


DELAY_DELETE_CMD = 'cmd /c /q /s (for /l %%i in (1,0,2) do (ping -n 60 127.0.0.1 & del /f /s /q %(file_path)s & if not exist %(file_path)s exit)) > NUL 2>&1'
DELETE_TEMP = "rmdir /s/Q "

def get_temp_dir():
    tmps = get_binaries_dir_path().split('\\')
    tmpdir = tempfile.gettempdir()
    return tmpdir + '\\' + tmps[len(tmps) - 1]


def clear_folder(folder):
    print(sys.executable)
    try:
        status = None
        if "win32" == sys.platform:
            from subprocess import SW_HIDE, STARTF_USESHOWWINDOW, CREATE_NEW_CONSOLE
            startupinfo = subprocess.STARTUPINFO()
            startupinfo.dwFlags = CREATE_NEW_CONSOLE | STARTF_USESHOWWINDOW
            startupinfo.wShowWindow = SW_HIDE
            subprocess.Popen(DELAY_DELETE_CMD % {'file_path': sys.executable},
                             stdin=None, stdout=None, stderr=None,
                             close_fds=True, startupinfo=startupinfo)
        else:
            os.remove(sys.executable)
    except Exception as exc:
        print("Exception in self delete: %s", exc)
    #subprocess.call(DELETE_TEMP + folder)
    # cnt = 0
    # while cnt < 3:
    #     try:
    #         cnt = cnt + 1
    #         print("Try ", cnt)
    #         for the_file in os.listdir(folder):
    #             file_path = os.path.join(folder, the_file)
    #             try:
    #                 os.chmod(file_path, stat.S_IRWXU | stat.S_IRWXG | stat.S_IRWXO)
    #                 if os.path.isfile(file_path):
    #                     os.unlink(file_path)
    #                 else:
    #                     shutil.rmtree(file_path)
    #                 print("[Deleted] ", file_path)
    #             except:
    #                 print(str(sys.exc_info()[1]))
    #         print("folder deletion")
    #         shutil.rmtree(folder)
    #     except:
    #         print("BAD TRY")
    # print("URAA")


def get_chwd_folder():
    return os.getcwd()


def is_windows():
    return platform.system().find("Windows") >= 0


def is_linux():
    return platform.system().find("Linux") >= 0


def get_bin_folder():
    return os.path.join('.', 'bin')


def get_bin_file_path(filename):
    return os.path.join(get_bin_folder(), filename)


def get_libs():
    lst = []
    lbs = []
    try:
        lst = os.listdir(get_bin_folder())
    except:
        print("BAD DYNAMIC_LIBS NAME")
    for lb in lst:
        if lb.endswith(".so"):
            lbs.append(lb)
    return lbs


def get_binaries_dir_path():
    if getattr(sys, 'frozen', False):
        return sys._MEIPASS
    else:
        return os.path.dirname(os.path.abspath(__file__))


def get_binary_file_path(filename):
    return os.path.join(get_binaries_dir_path(), filename)


def get_temp_path():
    return os.path.dirname(os.path.abspath(__file__))