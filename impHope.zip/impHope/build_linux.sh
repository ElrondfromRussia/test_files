#!/bin/bash
pyinstaller -F -w impl.spec
